<div class="card mt-3">
    <div class="card-header">
        <h4>Daftar Pendaftar</h4>
    </div>
    <div class="card-body">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Pendaftar</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>No</th>
                    <th>Nama Pendaftar</th>
                    <th>Keterangan</th>
                </tr>
            </tfoot>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Julistio Dido</td>
                    <td>
                        <button class="btn btn-success">Diterima</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
