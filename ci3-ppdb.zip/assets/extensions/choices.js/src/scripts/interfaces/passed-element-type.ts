export type PassedElementType = 'text' | 'select-one' | 'select-multiple';
